''' User input '''
low18=-16; up18=10; d18=0.1
low19=-10; up19=16; d19=0.1
nstate=2

''' Import library '''
import numpy

''' Do the job '''
with open('PotentialEnergySurface.txt','r') as f:
    data=f.readlines()
n18=up18-low18+1; n19=up19-low19+1
energy=numpy.empty((n18,n19,nstate))
indexdata=1
for i18 in range(n18):
    for i19 in range(n19):
        temp=data[indexdata].split(); indexdata=indexdata+1
        for j in range(nstate):
            energy[i18,i19,j]=float(temp[j+1].strip())
with open('ToPlot.txt','w') as f:
    for i18 in range(n18):
        for i19 in range(n19):
            print((i18+low18)*d18,(i19+low19)*d19,sep='\t',end='\t',file=f)
            for j in range(nstate):
                print(energy[i18,i19,j],end='\t',file=f)
            print(file=f)
